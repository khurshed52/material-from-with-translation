
export class HomeModal {
    name: string;
    email: string;
    date:  String;
    time:  String;
}
