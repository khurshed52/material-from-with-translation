export class TestModal {
    name: string;
    email: string;
    gender: string;
}
