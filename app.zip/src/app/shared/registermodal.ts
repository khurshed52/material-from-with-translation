export class RegisterModal {
    firstName: string;
    lastName: string;
    email: string;
    phone: number;
    date: string;
    country: string;
}
